﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PR14.Pages
{
    public partial class SeatSelectionPage : Page
    {
        private Films _film;
        private int _sessionId;
        private decimal _pricePerSeat;
        private List<SitSession> _sitSessions;           // все связи место-сеанс
        private List<int> _selectedSitIds = new List<int>();

        public SeatSelectionPage(Films film, int sessionId, decimal price)
        {
            InitializeComponent();
            _film = film;
            _sessionId = sessionId;
            _pricePerSeat = price;

            DataContext = this;

            LoadSeats();
            UpdateSelectedInfo();
        }

        // в SeatSelectionPage
        public string SessionInfo
        {
            get
            {
                var s = Core.Context.Session
                    .Where(x => x.SessionID == _sessionId)
                    .Select(x => new
                    {
                        Room = x.Room.RoomName,
                        Cat = x.Room.RoomCategory.Name,
                        Dt = x.SessionDate
                    })
                    .FirstOrDefault();

                return s != null
                    ? $"{s.Room} ({s.Cat}) • {s.Dt:dd.MM.yyyy}"
                    : "—";
            }
        }

        public string FilmName => _film.FilmName;

        private void LoadSeats()
        {
            _sitSessions = Core.Context.SitSession
                .Where(ss => ss.SessionID == _sessionId)
                .OrderBy(ss => ss.Sit.Number)
                .ToList();

            SeatsGrid.ItemsSource = _sitSessions.Select(ss => new
            {
                SitSessionID = ss.SitSessionID,
                Number = ss.Sit.Number,
                IsTaken = ss.IsTake,
                Background = ss.IsTake ? Brushes.Gray : Brushes.DarkGreen
            }).ToList();
        }

        private void SeatButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int sitSessionId)
            {
                var ss = _sitSessions.FirstOrDefault(x => x.SitSessionID == sitSessionId);
                if (ss == null || ss.IsTake) return;

                if (_selectedSitIds.Contains(sitSessionId))
                {
                    _selectedSitIds.Remove(sitSessionId);
                    btn.Background = Brushes.DarkGreen;
                }
                else
                {
                    _selectedSitIds.Add(sitSessionId);
                    btn.Background = Brushes.Orange;
                }

                UpdateSelectedInfo();
            }
        }

        private void UpdateSelectedInfo()
        {
            if (_selectedSitIds.Count == 0)
            {
                tbSelectedSeats.Text = "Места не выбраны";
                btnBuy.IsEnabled = false;
            }
            else
            {
                var total = _selectedSitIds.Count * _pricePerSeat;
                tbSelectedSeats.Text = $"Выбрано: {_selectedSitIds.Count} × {_pricePerSeat:N2} ₽ = {total:N2} ₽";
                btnBuy.IsEnabled = true;
            }
        }

        private void BuyTicket_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedSitIds.Count == 0) return;

            NavigationService?.Navigate(new TicketConfirmationPage(
                _film,
                _sessionId,
                _selectedSitIds,
                _pricePerSeat
            ));
        }
    }
}